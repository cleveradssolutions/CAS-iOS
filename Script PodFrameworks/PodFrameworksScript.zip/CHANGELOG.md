# CAS.AI iOS XCode Config script change log

# [1.1] - Nov 13, 2023
- Certified with CAS 3.4.1 (Use `--version` to set CAS version).
- Improved search for resource bundles.
- Updated XCode configuration output.
- Fixed some bugs.